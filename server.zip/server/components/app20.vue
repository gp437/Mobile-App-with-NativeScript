<template>
    <Page actionBarHidden="true">>
        <ScrollView>
            <StackLayout class="home-panel">
                <Label text="Home page content" />
            </StackLayout>
        </ScrollView>
        <!-- tabs -->

        <StackLayout>
            <BottomNavigation>
                <TabStrip>
                    <TabStripItem>
                        <Label text="Login" fontSize="16px"></Label>
                        <Image src="res://">
                        </Image>
                    </TabStripItem>
                    <TabStripItem>
                        <Label text="Activities" fontSize="16px">
                        </Label>
                        <!-- <Image src="res://settings"></Image> -->
                    </TabStripItem>
                    <TabStripItem>
                        <Label text="Sign up" fontSize="16px"></Label>
                        <!-- <Image src="res://search"></Image> -->
                    </TabStripItem>
                </TabStrip>

                <!-- login page -->
                <TabContentItem width="100%" height="100%">

                    <!-- login form -->
                    <FlexboxLayout class="page">
                        <Label text="Login Page" class="h2 text-center">
                        </Label>
                        <Image class="logo"
                            src="https://www.pngkey.com/png/full/255-2559651_sport-clip-extra-curricular-activity-co-curricular-activities.png" />
                        <Label class="header" text="AFTER SCHOOL">
                        </Label>
                        <StackLayout class="form">
                            <StackLayout row="0" class="input-field">
                                <TextField class="input" hint="Email"
                                    :isEnabled="!processing"
                                    keyboardType="email" autocorrect="false"
                                    autocapitalizationType="none"
                                    v-model="user.email" returnKeyType="next"
                                    @returnPress="focusPassword">
                                </TextField>
                                <StackLayout class="hr-light">
                                </StackLayout>
                            </StackLayout>

                            <StackLayout row="1" class="input-field">
                                <TextField class="input" ref="password"
                                    :isEnabled="!processing" hint="Password"
                                    secure="true" v-model="user.password"
                                    :returnKeyType="isLoggingIn ? 'done' : 'next'"
                                    @returnPress="focusConfirmPassword">
                                </TextField>
                                <StackLayout class="hr-light">
                                </StackLayout>
                            </StackLayout>
                            <!-- login button -->
                            <Button text="Log In" class="btn btn-primary"
                                @tap="loginButton">
                            </Button>
                        </StackLayout>
                    </FlexboxLayout>
                    <!-- end form -->
                </TabContentItem>
                <!-- activities page -->
                <TabContentItem>
                    <Label text=" Activities Page" class="h2 text-center">



                </TabContentItem>

                <!-- sign up page -->
                <TabContentItem>
                    <Label text="Register From" fontSize="20px" color="green"
                        horizontalAlignment="center" />
                    <StackLayout class="form">
                        <StackLayout row="0" class="input-field">
                            <TextField class="input" hint="Name"
                                :isEnabled="!processing" autocorrect="false"
                                autocapitalizationType="none"
                                v-model="user.name" returnKeyType="next"
                                @returnPress="focusPassword">
                            </TextField>
                            <!-- end name -->
                            <TextField class="input" hint="User Type"
                                :isEnabled="!processing" autocorrect="false"
                                autocapitalizationType="none"
                                v-model="user.userType" returnKeyType="next"
                                @returnPress="focusPassword">
                            </TextField>
                            <!-- end user type -->
                            <TextField class="input" hint="Email"
                                :isEnabled="!processing" keyboardType="email"
                                autocorrect="false"
                                autocapitalizationType="none"
                                v-model="user.email" returnKeyType="next"
                                @returnPress="focusPassword">
                            </TextField>
                            <StackLayout class="hr-light">
                            </StackLayout>
                        </StackLayout>

                        <StackLayout row="1" class="input-field">
                            <TextField class="input" ref="password"
                                :isEnabled="!processing" hint="Password"
                                secure="true" v-model="user.password"
                                @returnPress="focusConfirmPassword">
                            </TextField>
                            <StackLayout class="hr-light">
                            </StackLayout>
                        </StackLayout>
                        <!-- login button -->
                        <Button text="Sign Up" class="btn btn-primary"
                            @tap="registerButton">
                        </Button>
                    </StackLayout>
                    </FlexboxLayout>
                    <!-- end form -->

                </TabContentItem>
            </BottomNavigation>
        </StackLayout>
        <!-- end tabs -->
    </Page>
</template>

<script>
    let validEmail = 0;
    let validEP = 0;
    let givenEmail = "";
    let allUsers = [];
    let dbEmail = "";
    let dbPassword = "";

    export default {
        data() {
            return {
                user: {
                    email: "",
                    password: "",
                    name: "",
                    userType: ""
                },
                btnDisable: "false"
            };
        },
        methods: {
            // start of loginFunc
            loginFunc() {
                if (!this.user.email || !this.user.password) {
                    this.alert(
                        "Please provide both an email address and password."
                    );
                    validEP = 0;
                    console.log("complete email and password status: " +
                        validEP);
                }
                if (this.user.email || this.user.password) {
                    validEP = 1;
                }
            },

            // validate email
            validateEmail() {
                if (
                    /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(
                        this.user.email
                    )
                ) {
                    validEmail = 1;
                    console.log("email status: " + validEmail);
                } else {
                    validEmail = 0;
                    console.log("email status: " + validEmail);
                    this.alert(
                        "The format of the email entered is incorrect. Please try again."
                    );
                }
            },
            // fech user
            FechUser() {
                fetch("https://31df211f.ngrok.io/users/email/" + this.user
                        .email)
                    .then(response => response.json())
                    .then(data => {
                        this.allUsers = data.data;
                        console.log(data.password);
                        dbEmail = data.email;
                        dbPassword = data.password;
                        if (this.user.email == data.email) {
                            if (this.user.password == data.password) {
                                {
                                    this.alert(
                                        "You are now logged in as: " +
                                        data.email
                                    );
                                    console.log(
                                        "email and password are maching "
                                        );
                                }
                            }
                        }

                        if (
                            this.user.email != data.email ||
                            this.user.password != data.password
                        ) {
                            console.log("Wrong password or email ");
                            this.alert(
                                "Password entered is incorrect. Please try again."
                            );
                            console.log(data.email);
                        }
                    });
            },

            //end fech func

            // alert message func
            alert(message) {
                return alert({
                    title: "AFTER SCHOOL ACTIVITIES",
                    okButtonText: "OK",
                    message: message
                });
            },
            loginButton() {
                this.loginFunc();
                this.validateEmail();
                if (validEmail == 1 || validEP == 1) {
                    this.FechUser();
                }
            },
            registerButton() {
                let params = {
                    name: this.user.name,
                    email: this.user.email,
                    userType: this.user.userType,
                    password: this.user.password
                };
                let name1 = this.user.name;
                let email = this.user.email;
                let userType1 = this.user.userType;
                let password1 = this.user.password;
                
                let name: name1;
                let email: email1;
                let userType: userType1;
                let password: password1;
                fetch("https://405376ef.ngrok.io/users/new/" + "51", {
                    method: "post",
                    headers: {
                        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8"
                    },

                    body: (name = this.user.name)
                });
            }
        }
    };
</script>


<style scoped>
    .page {
        align-items: center;
        flex-direction: column;
    }

    .form {
        margin-left: 30;
        margin-right: 30;
        flex-grow: 2;
        vertical-align: middle;
    }

    .logo {
        margin-bottom: 5;
        height: 90;
        font-weight: bold;
    }

    .header {
        horizontal-align: center;
        font-size: 25;
        font-weight: 600;
        margin-bottom: 5;
        text-align: center;
        color: green;
    }

    .input-field {
        margin-bottom: 5;
    }

    .input {
        font-size: 18;
        placeholder-color: green;
    }

    .input:disabled {
        background-color: grey;
        opacity: 0.5;
    }

    .btn-primary {
        margin: 5 5 25 5;
    }

    .login-label {
        horizontal-align: center;
        color: grey;
        font-size: 16;
    }

    .sign-up-label {
        margin-bottom: 5;
    }

    .bold {
        color: #000000;
    }
</style>