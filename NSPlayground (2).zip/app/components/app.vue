<template>
    <Page actionBarHidden="true">>
        <ScrollView>
            <StackLayout class="home-panel">
                <Label text="Home page content" />
            </StackLayout>
        </ScrollView>
        <!-- tabs -->

        <StackLayout>
            <BottomNavigation>
                <TabStrip>
                    <TabStripItem>
                        <Label text="Login" fontSize="16px"></Label>
                        <Image src="res://">
                        </Image>
                    </TabStripItem>
                    <TabStripItem>
                        <Label text="Activities" fontSize="16px">
                        </Label>
                        <!-- <Image src="res://settings"></Image> -->
                    </TabStripItem>
                    <TabStripItem>
                        <Label text="Sign up" fontSize="16px"></Label>
                        <!-- <Image src="res://search"></Image> -->
                    </TabStripItem>
                </TabStrip>

                <!-- login page -->
                <TabContentItem width="100%" height="100%">

                    <!-- login form -->
                    <FlexboxLayout class="page">
                        <Label text="Login Page" class="h2 text-center">
                        </Label>
                        <Image class="logo"
                            src="https://www.pngkey.com/png/full/255-2559651_sport-clip-extra-curricular-activity-co-curricular-activities.png" />
                        <Label class="header" text="AFTER SCHOOL">
                        </Label>
                        <StackLayout class="form">
                            <StackLayout row="0" class="input-field">
                                <TextField class="input" hint="Email"
                                    :isEnabled="!processing"
                                    keyboardType="email" autocorrect="false"
                                    autocapitalizationType="none"
                                    v-model="user.email" returnKeyType="next"
                                    @returnPress="focusPassword">
                                </TextField>
                                <StackLayout class="hr-light">
                                </StackLayout>
                            </StackLayout>

                            <StackLayout row="1" class="input-field">
                                <TextField class="input" ref="password"
                                    :isEnabled="!processing" hint="Password"
                                    secure="true" v-model="user.password"
                                    :returnKeyType="isLoggingIn ? 'done' : 'next'"
                                    @returnPress="focusConfirmPassword">
                                </TextField>
                                <StackLayout class="hr-light">
                                </StackLayout>

                            </StackLayout>
                            <!-- login button -->
                            <Button text="Log In" class="btn btn-primary"
                                @tap="loginButton">

                        </StackLayout>
                        <!-- height="100%" -->
                        <!-- log out -->
                        <Button text="Log Out" @tap="logOutButton">
                        </Button>
                    </FlexboxLayout>
                    <!-- end form -->
                </TabContentItem>
                <!-- activities page -->
                <TabContentItem>
                    <Label text=" Activities Page" class="h2 text-center">
                    </Label>




                    <RadSideDrawer ref="drawer">
                        <StackLayout ~drawerContent>
                            <Label text="Filter by Topic" class='h2' />
                            <!-- <Label v-for='country in sortFunc()'  :text='country.topic' @tap='filterFunc' " /> -->
                            <ListView for='country in sortFunc()'
                                @itemTap="onItemTap" style="height:100%"
                                width="100%">
                                <v-template>
                                    <FlexboxLayout flexDirection="column">
                                        <Label :text="country.topic"
                                            class="t-12"
                                            style="width: 100%" />
                                        <Label text="Sort by title  Ascending"
                                            @tap='sortAscendTitle' />
                                        <Label
                                            text="Sort by title  Descending"
                                            @tap='sortDescendTitle' />

                                        <Label text="Sort by Price  Ascending"
                                            @tap='sortAscendPrice' />
                                        <Label
                                            text="Sort by Price  Descending"
                                            @tap='sortDescendPrice' />
                                    </FlexboxLayout>
                                </v-template>
                            </ListView>
                            <!-- v-model="filterValue" -->
                            <!-- <TextField :text='country.topic' v-model="filterValue" hint="" /> -->






                            <Label text="Close Drawer" color="red"
                                padding="10" style="horizontal-align: center"
                                @tap="onCloseDrawerTap">
                            </Label>
                        </StackLayout>
                        <StackLayout ~mainContent>
                            <StackLayout orientation="Horizontal">
                                <!-- <Button text="Sort" @tap="onOpenDrawerTap()"
                                    class="drawerContentButton"></Button> -->

                                <Button text="Sort and Filter"
                                    @tap="onToggleDrawerTap()"
                                    class="drawerContentButton"></Button>
                            </StackLayout>

                            <!-- search button -->
                            <TextField v-model="searchValue" hint="Search" />
                            <!-- end seearch button -->
                            <Button text="Search" @tap="Results()">
                            </Button>

                            <!-- <Button text="Show Courses" @tap="FechCourses()">
                            </Button> -->

                            <!-- list view classes -->
                            <ListView for="country in sortFunc()"
                                @itemTap="onItemTap" style="height:100%"
                                width="100%">
                                <v-template>
                                    <FlexboxLayout flexDirection="column">
                                        <Image :src="country.image" />

                                        <Label text="Activity/Class title"
                                            style="color: red" />

                                        <Label :text="country.title"
                                            class="t-12"
                                            style="width: 100%" />

                                        <Label text="Topic"
                                            style="color: red" />
                                        <Label :text="country.topic"
                                            class="t-12"
                                            style="width: 100%" />

                                        <Label text="Location"
                                            style="color: red" />
                                        <Label :text="country.location"
                                            class="t-12"
                                            style="width: 100%" />

                                        <Label text="Price"
                                            style="color: red" />
                                        <Label :text="country.price"
                                            class="t-12"
                                            style="width: 100%" />

                                        <Label text="Provider"
                                            style="color: red" />
                                        <Label :text="country.provider"
                                            class="t-12"
                                            style="width: 100%" />



                                    </FlexboxLayout>
                                </v-template>
                            </ListView>
                            <!-- end list view classes -->
                        </StackLayout>
                </TabContentItem>
                <!-- end activities  page -->


                <!-- sign up page start -->
                <TabContentItem>
                    <Label text="Register From" fontSize="20px" color="green"
                        horizontalAlignment="center" />
                    <StackLayout class="form">
                        <StackLayout row="0" class="input-field">
                            <TextField class="input" hint="Name"
                                :isEnabled="!processing" autocorrect="false"
                                autocapitalizationType="none"
                                v-model="user.name" returnKeyType="next"
                                @returnPress="focusPassword">
                            </TextField>
                            <!-- end name -->
                            <TextField class="input" hint="User Type"
                                :isEnabled="!processing" autocorrect="false"
                                autocapitalizationType="none"
                                v-model="user.userType" returnKeyType="next"
                                @returnPress="focusPassword">
                            </TextField>
                            <!-- end user type -->
                            <TextField class="input" hint="Email"
                                :isEnabled="!processing" keyboardType="email"
                                autocorrect="false"
                                autocapitalizationType="none"
                                v-model="user.email" returnKeyType="next"
                                @returnPress="focusPassword">
                            </TextField>
                            <StackLayout class="hr-light">
                            </StackLayout>
                        </StackLayout>

                        <StackLayout row="1" class="input-field">
                            <TextField class="input" ref="password"
                                :isEnabled="!processing" hint="Password"
                                secure="true" v-model="user.password"
                                @returnPress="focusConfirmPassword">
                            </TextField>
                            <StackLayout class="hr-light">
                            </StackLayout>
                        </StackLayout>
                        <!-- login button -->
                        <Button text="Sign Up" class="btn btn-primary"
                            @tap="RegisterCheck">
                        </Button>
                    </StackLayout>
                    </FlexboxLayout>
                    <!-- end form -->

                </TabContentItem>
            </BottomNavigation>
        </StackLayout>
        <!-- end tabs -->
    </Page>
</template>






<script>
    import Vue from "nativescript-vue";
    import RadSideDrawer from "nativescript-ui-sidedrawer/vue";
    Vue.use(RadSideDrawer);
    let topic;
    let validEmail = 0;
    let validEP = 0;
    let givenEmail = "";
    let coursesData = [];
    let dbEmail = "";
    let dbPassword = "";
    let unixDate = Date.now();
    let emailUsed;
    let id;
    let id0;
    let sortedA;
    // sort title
    let sortTitle = "AZ";

    // sort price
    let sortPrice;

    function replacer(key, value) {
        // Filtering out properties
        if (typeof value === "string") {
            return undefined;
        }
        return value;
    }

    export default {
        data() {
            return {
                textFieldValue: "",
                resultsFound: [],
                filterValue: "",
                loggedIn: 0,

                countries: [{
                    title: "",
                    topic: "",
                    location: "",
                    price: ""
                }],

                user: {
                    email: "",
                    password: "",
                    name: "",
                    userType: "",
                    title: "Side Drawer example",
                    locations: ["hendon", "brent cross", "golders green"]
                },
                allClasses: [],
                btnDisable: "false",
                activitiesA: [],
                topic: ""
            };
        },
        methods: {
            onItemTap: function(args) {
                console.log("Item with index: " + args.item.topic +
                    " tapped");
                this.filterValue = args.item.topic;
                console.log("filterValue on itemtap  is  " + this
                    .filterValue);
                this.filterFunc();
            },

            // sidedrawer
            onOpenDrawerTap() {
                this.$refs.drawer.showDrawer();
            },
            onCloseDrawerTap() {
                this.$refs.drawer.closeDrawer();
            },
            onToggleDrawerTap() {
                this.$refs.drawer.toggleDrawerState();
            },

            // sorting function starts
            sortFunc() {
                if (sortPrice === "AZ") {
                    return this.countries.slice().sort(function(a, b) {
                        return a.price > b.price ? 1 : -1;
                    });
                } else if (sortPrice === "ZA") {
                    return this.countries.slice().sort(function(a, b) {
                        return a.price < b.price ? 1 : -1;
                    });
                }

                if (sortTitle == "AZ") {
                    return this.countries.slice().sort(function(a, b) {
                        return a.title > b.title ? 1 : -1;
                    });
                } else if (sortTitle == "ZA") {
                    return this.countries.slice().sort(function(a, b) {
                        return a.title < b.title ? 1 : -1;
                    });
                }
            },
            // end sorting function

            sortAscendTitle() {
                console.log("sortAscend Title pressed.");
                sortTitle = "AZ";
                this.sortFunc();
                this.FechCourses();
            },

            sortDescendTitle() {
                console.log("sortDescend Title pressed.");
                sortTitle = "ZA";
                this.sortFunc();
                this.FechCourses();
            },

            sortAscendPrice() {
                sortPrice = "AZ";
                this.sortFunc();
                console.log("Sort Ascend Price pressed");
                this.FechCourses();
            },

            sortDescendPrice() {
                sortPrice = "ZA";
                this.sortFunc();
                console.log("Sort Descend Price pressed");
                this.FechCourses();
            },

            // start of loginFunc
            loginFunc() {
                if (!this.user.email || !this.user.password) {
                    this.alert(
                        "Please provide both an email address and password."
                    );
                    validEP = 0;
                    console.log("complete email and password status: " +
                        validEP);
                }
                if (this.user.email || this.user.password) {
                    validEP = 1;
                }
            },

            // validate email
            validateEmail() {
                if (
                    /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(
                        this.user.email
                    )
                ) {
                    validEmail = 1;
                    console.log("email status: " + validEmail);
                } else {
                    validEmail = 0;
                    console.log("email status: " + validEmail);
                    this.alert(
                        "The format of the email entered is incorrect. Please try again."
                    );
                }
            },

            // fech user
            FechUser() {
                fetch("https://87a86d7b.ngrok.io/users/email/" + this.user
                        .email)
                    .then(response => response.json())
                    .then(data => {
                        this.allUsers = data.data;
                        console.log(data.password);
                        dbEmail = data.email;
                        dbPassword = data.password;
                        if (this.user.email == data.email) {
                            if (this.user.password === data.password) {
                                {
                                    this.alert(
                                        "You are now logged in as: " +
                                        data.email
                                    );
                                    this.alert(
                                        "Now you can access the activities/classes"
                                    );

                                    this.loggedIn = 1;
                                    console.log(
                                        "email and password are maching "
                                        );
                                }
                            }
                        }

                        if (
                            this.user.email != data.email ||
                            this.user.password != data.password
                        ) {
                            console.log("Wrong password or email ");
                            this.alert(
                                "Password entered is incorrect. Please try again."
                            );
                            console.log(data.email);
                        }
                    });
            },
            //end fech func

            // alert message func
            alert(message) {
                return alert({
                    title: "AFTER SCHOOL ACTIVITIES",
                    okButtonText: "OK",
                    message: message
                });
            },
            loginButton() {
                this.loginFunc();
                this.validateEmail();
                this.FechCourses();
                if (validEmail == 1 || validEP == 1) {
                    this.FechUser();
                }
                this.FechCourses();
            },

            // register checks
            RegisterCheck() {
                if (!this.user.email || !this.user.password) {
                    validEP = 0;
                    console.log("F password and email:  " + validEP);
                    this.alert(
                        "Please provide both an email address and password."
                    );
                }
                if (this.user.email || this.user.password) {
                    validEP = 1;
                    console.log("T password and email: " + validEP);
                    this.EmailFormat();
                }
            },

            EmailFormat() {
                if (
                    /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(
                        this.user.email
                    )
                ) {
                    validEmail = 1;
                    console.log("T email format " + validEmail);
                    this.UserExists();
                } else {
                    this.alert("Incorrect email format.");
                }
            },
            FechUserRegister() {
                fetch("https://87a86d7b.ngrok.io/users/email/" + this.user
                        .email)
                    .then(response => response.json())
                    .then(data => {
                        this.allUsers = data.data;
                        dbEmail = data.email;
                        console.log("email from database " + dbEmail);
                        this.UserExists();
                    });
            },

            UserExists() {
                if (this.user.email !== dbEmail) {
                    console.log("Email is not used: " + dbEmail);
                    this.SaveUser();
                } else {
                    this.alert("An account with this email already exists.");
                }
            },
            SaveUser() {
                let name1 = this.user.name;
                let email1 = this.user.email;
                let userType1 = this.user.userType;
                let password1 = this.user.password;

                {
                    id0 = unixDate + 1;
                    id = id0;
                    console.log(id);
                    fetch("https://87a86d7b.ngrok.io/users/new/" + id, {
                        method: "post",
                        headers: {
                            "content-type": "application/json"
                        },
                        body: JSON.stringify({
                            name: name1,
                            email: email1,
                            userType: userType1,
                            password: password1
                        })
                    });
                    id0 = id + 1;
                    this.alert(
                        "Your account has been registered. Please go to log in"
                    );
                }
            },
            // end register button func

            FechCourses() {
                fetch("https://87a86d7b.ngrok.io/courses")
                    .then(response => response.json())
                    .then(data => {
                        this.countries = data;
                        console.log(this.countries);
                    });
            },

            Results() {
                if (this.loggedIn == 1) {
                    fetch("https://87a86d7b.ngrok.io/courses")
                        .then(response => response.json())
                        .then(data => {
                            this.countries = [];
                            this.resultsFound = data;
                            for (var i = 0; i < this.resultsFound
                                .length; i++) {
                                if (
                                    this.resultsFound[i].topic.includes(
                                        this.searchValue
                                    )
                                ) {
                                    this.countries.push(this.resultsFound[
                                        i]);
                                }
                            }
                        });
                }
                if (this.loggedIn == 0) {
                    this.alert("You are not logged in. Please log in.");
                }
            },

            filterFunc() {
                fetch("https://87a86d7b.ngrok.io/courses")
                    .then(response => response.json())
                    .then(data => {
                        this.countries = [];
                        this.resultsFound = data;
                        for (var i = 0; i < this.resultsFound
                            .length; i++) {
                            if (
                                this.resultsFound[i].topic.includes(
                                    this.filterValue
                                )
                            ) {
                                this.countries.push(this.resultsFound[i]);
                            }
                        }
                    });
            },
            logOutButton() {
                this.loggedIn = 0;
                this.countries = [];
                this.alert("Logged Out.");
            }
        }
    };
</script>

<style scoped>
    Label,
    Button {
        font-size: 18rem;
        padding: 20px
    }

    .page {
        align-items: center;
        flex-direction: column;
    }

    .form {
        margin-left: 30;
        margin-right: 30;
        flex-grow: 2;
        vertical-align: middle;
    }

    .logo {
        margin-bottom: 5;
        height: 90;
        font-weight: bold;
    }

    .header {
        horizontal-align: center;
        font-size: 25;
        font-weight: 600;
        margin-bottom: 5;
        text-align: center;
        color: green;
    }

    .input-field {
        margin-bottom: 5;
    }

    .input {
        font-size: 18;
        placeholder-color: green;
    }

    .input:disabled {
        background-color: grey;
        opacity: 0.5;
    }

    .btn-primary {
        margin: 5 5 25 5;
    }

    .login-label {
        horizontal-align: center;
        color: grey;
        font-size: 16;
    }

    .sign-up-label {
        margin-bottom: 5;
    }

    .bold {
        color: #000000;
    }
</style>